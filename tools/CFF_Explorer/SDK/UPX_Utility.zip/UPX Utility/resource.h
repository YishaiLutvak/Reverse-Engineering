//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by UPX Utility.rc
//
#define DLG_EXTENSION                   101
#define IDC_OK                          1001
#define CB_CHECKPACK                    1003
#define CB_PACKEXPORTS                  1004
#define CB_PACKRES                      1005
#define CB_ICONS                        1006
#define CB_STRIPRELOCS                  1007
#define CB_FORCE                        1008
#define CB_ALLMETHODS                   1009
#define CB_ALLFILTERS                   1010
#define IDC_PACK                        1011
#define IDC_UNPACK                      1012
#define CB_PACKLEVEL                    1014
#define CB_EXACT                        1015
#define GB_CHECKPACK                    1016
#define GB_UPX                          1017
#define ED_RESULT                       1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
